export interface CreateParametrosDTO {
  nome: string;
  numero_coren: string;
  aplicarIST?: boolean;
  ist?: number;
  diasSemana?: number;
}
