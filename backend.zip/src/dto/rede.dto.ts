export interface CreateRedeDTO {
  nome: string;
}

export interface AtualizarRedeDTO {
  nome?: string;
}
