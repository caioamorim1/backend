import { Router } from "express";
import { DataSource } from "typeorm";

export const InternacaoRoutes = (ds: DataSource): Router => {
  const r = Router();

  return r;
};
